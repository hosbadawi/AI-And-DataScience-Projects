﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventModel
{
    public class BikeRentalEvents
    {
        private int marker = 0;

        private List<BikeData> bikeDataCollection = new List<BikeData>();
        public string FileName
        {
            get;
            set;
        }

        public void Initialize(string file)
        {
            FileName = file;

            if (!File.Exists(FileName))
            {
                throw new Exception(String.Format("File {0} does not exist", FileName));
            }
        }

        public List<BikeData> GetBatch(int size = 20)
        {
            var bikeDataCollection = JsonConvert.DeserializeObject<List<BikeData>>(File.ReadAllText(FileName));
            int length = bikeDataCollection.Count;

            var list = new List<BikeData>();

            int end = ((marker + size) > length) ? length : marker + size;

            for (var i = marker; i < end; i++)
            {
                list.Add(bikeDataCollection[i]);
            }
            marker = end;

            return list;
        }
    }
}