﻿using Newtonsoft.Json;
using System;

namespace EventModel
{
    public class BikeData
    {
        /* {
        "Trip ID": "913460",
        "Duration": "765",
        "Start Date": "8/31/2015 23:26",
        "Start Station": "Harry Bridges Plaza (Ferry Building)",
        "Start Terminal": "50",
        "End Date": "8/31/2015 23:39",
        "End Station": "San Francisco Caltrain (Townsend at 4th)",
        "End Terminal": "70",
        "Bike #": "288",
        "Subscriber Type": "Subscriber",
        "Zip Code": "2139"}
        */

        // Convert using https://json2csharp.com/

        [JsonProperty("Trip ID")]
        public string TripID { get; set; }
        public string Duration { get; set; }

        [JsonProperty("Start Date")]
        public string StartDate { get; set; }

        [JsonProperty("Start Station")]
        public string StartStation { get; set; }

        [JsonProperty("Start Terminal")]
        public string StartTerminal { get; set; }

        [JsonProperty("End Date")]
        public string EndDate { get; set; }

        [JsonProperty("End Station")]
        public string EndStation { get; set; }

        [JsonProperty("End Terminal")]
        public string EndTerminal { get; set; }

        [JsonProperty("Bike #")]
        public string Bike { get; set; }

        [JsonProperty("Subscriber Type")]
        public string SubscriberType { get; set; }

        [JsonProperty("Zip Code")]
        public string ZipCode { get; set; }

        public DateTime ProcessDate { get; set; }
    }
}

